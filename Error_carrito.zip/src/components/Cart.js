import AppContext from "../context/AppContext"
import React, { useState, useContext } from "react"
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import Modal from 'react-bootstrap/Modal'
import Button from 'react-bootstrap/Button'
import CartItem from "./CartItem"
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

function Cart(props) {
    const context = useContext(AppContext)
    const cartItems = context.cartItems.map(item =>
        <CartItem
            key={item.id}
            id={item.id} 
            name={item.name} 
            price={item.price}
            photo_url={item.photo_url}
            stock={item.stock}
        />)
    
    const row_style = {
        display: "flex",
        alignItems: "center",
        border: "1px solid lightgrey",
        borderRadius: "10px",
        marginBottom: "1em",
        padding: "0.5em"
    }

    return (
        <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        >
      <Modal.Header as="section" closeButton>
        <Modal.Title as="h4" bsPrefix="cart-title">
          Carrito de compras
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="text-center">
        <Container>
            {context.cartItems.length === 0 ? <p>El carrito se encuentra vacío</p>
            : cartItems}
            <Row style={row_style}>
                <Col>
                    <h4>Total:</h4>
                </Col>
                <Col>
                    Hola
                </Col>
            </Row>
        </Container>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="outline-success" onClick={props.onHide}>Iniciar Compra</Button>
      </Modal.Footer>
    </Modal>
  )
}

export default Cart