import React, { useState, useContext, useEffect } from "react"
import AppContext from "../context/AppContext"
import { CSSTransition } from "react-transition-group"
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Adder from "./Adder"
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';

const CartItem = (props) => {
    const context = useContext(AppContext)

    const [cantidad, setCantidad] = useState(1)
    const [visible, setVisible] = useState(true)

    useEffect(()=>console.log(`Al montar ${props.name}, visible es ${visible}`), [visible])

    let precioFinal = props.price * cantidad

    const handleClick = () => {
        setVisible(false)    
        console.log(`Ahora visible de ${props.name} es ${visible}`)
    }

    const img_style = {
        maxWidth: 60
    }

    const row_style = {
        display: "flex",
        alignItems: "center",
        border: "1px solid lightgrey",
        borderRadius: "10px",
        marginBottom: "1em",
        padding: "0.5em"
    }

    const exit = ()=> {
        context.removeFromCart(props)
    }

    return (
        <CSSTransition 
            in={visible} 
            timeout={1000} 
            classNames="cart-item"
            onExited={()=>exit()}
        >
            <Row style={row_style}>
                <Col>
                    <img src={props.photo_url} style={img_style}/>
                </Col>
                <Col xs={4}>
                    {props.name}
                </Col>
                <Col xs={3}>
                    Cantidad: <Adder cantidad={cantidad} setCantidad={setCantidad}/>
                </Col>
                <Col>
                    Precio: ${precioFinal}
                </Col>
                <Col>
                <IconButton onClick={handleClick} className="delete-button">
                    <DeleteIcon className="delete-button"/>
                </IconButton>
                </Col>
            </Row>
        </CSSTransition>
    )
}

export default CartItem