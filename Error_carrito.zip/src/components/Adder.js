
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import RemoveCircleOutlineIcon from '@material-ui/icons/RemoveCircleOutline';
import IconButton from '@material-ui/core/IconButton';
import React, { useState } from "react"

const Adder = (props) => {
    const handleClick = (name) => () => {
        if (name === "plus") {
            (props.setCantidad(props.cantidad + 1))
        }
        else {
            if (props.cantidad > 1){
                props.setCantidad(props.cantidad - 1)
            }   
        }
    }
    return(
        <div>
        <IconButton name="plus" onClick={handleClick("plus")}>
            <AddCircleOutlineIcon />
        </IconButton>
            {props.cantidad}
        <IconButton onClick={handleClick("minus")}>
            <RemoveCircleOutlineIcon />
        </IconButton>
        </div>
    )
}

export default Adder